
<?php $taskId = 'Task number '. $task->id; ?>
<?php $__env->startSection('title', $taskId); ?>

<?php $__env->startSection('main'); ?>

<?php
setlocale(LC_TIME, 'French');
$date = 'le '.$task->created_at->formatLocalized('%d %B %Y');

?>


<strong>Title:</strong> <?php echo e($task->title); ?><br />
<strong>Description:</strong> <?php echo e($task->description); ?><br />
<strong>Created at:</strong> <?php echo e($date); ?><br /><br />

<a style="color: blue;"href="/delete/<?php echo e($task->id); ?>">Delete task</a>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts/layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\wamp64\www\examdevbackend\resources\views/viewtask.blade.php ENDPATH**/ ?>