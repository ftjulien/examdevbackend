
<?php $success = 'Task number '.$task->id. ' successfully deleted.'; ?>
<?php $__env->startSection('title', $success); ?>

<?php $__env->startSection('main'); ?>
Thank you for deleting the task <?php echo e($task->id); ?>. You will be redirected in 5 seconds.
<?php header( "refresh:5;url=/" ); ?>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts/layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\wamp64\www\examdevbackend\resources\views/deletetask.blade.php ENDPATH**/ ?>