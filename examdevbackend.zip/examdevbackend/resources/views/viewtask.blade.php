@extends('layouts/layout')
<?php $taskId = 'Task number '. $task->id; ?>
@section('title', $taskId)

@section('main')

<?php
setlocale(LC_TIME, 'French');
$date = 'le '.$task->created_at->formatLocalized('%d %B %Y');

?>


<strong>Title:</strong> {{$task->title}}<br />
<strong>Description:</strong> {{$task->description}}<br />
<strong>Created at:</strong> {{$date}}<br /><br />

<a style="color: blue;"href="/delete/{{$task->id}}">Delete task</a>

@endsection