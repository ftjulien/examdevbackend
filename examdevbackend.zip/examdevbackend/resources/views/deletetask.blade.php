@extends('layouts/layout')
<?php $success = 'Task number '.$task->id. ' successfully deleted.'; ?>
@section('title', $success)

@section('main')
Thank you for deleting the task {{$task->id}}. You will be redirected in 5 seconds.
<?php header( "refresh:5;url=/" ); ?>
@endsection