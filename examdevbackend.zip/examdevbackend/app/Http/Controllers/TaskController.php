<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;

class TaskController extends Controller
{
    public function index()
    {
        return view('index', [
            'tasks' => \App\Models\Task::all(),
        ]);
    }
    public function viewtask($id){

    		$task = \App\Models\Task::findOrFail($id);
    		return view('viewtask', ['task' => $task]);

    }
    public function indexAlpha(){

        return view('indexAlpha', [
            'tasks' => \App\Models\Task::orderBy('title')->get(),
        ]);
    }
}
