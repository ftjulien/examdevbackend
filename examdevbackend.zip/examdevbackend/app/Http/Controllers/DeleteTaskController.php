<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;

class DeleteTaskController extends Controller
{
        public function deleteTask($id){

    		$task = \App\Models\Task::findOrFail($id);
    		$task->delete();
    		return view('deletetask', ['task' => $task]);

    }
}
